# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: acceptance.spec.ts >> portrait-dpr3 >> [hud-portrait-dpr3-normal] Live full-size HUD portrait-dpr3 normal
- Location: browser-acceptance/acceptance.spec.ts:219:49

# Error details

```
Error: Full visible text must be complete, unclipped and unobscured

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 33

- Array []
+ Array [
+   "text[32] site:campaign-site:11 \"友24 / 予24\": text-crosses-clip at style:campaign-site-force:45",
+   "text[33] site:campaign-site:11 \"砲台あり\": text-crosses-clip at style:campaign-site-wave:47",
+   "text[34] site:campaign-site:11 \"· 補30s\": text-crosses-clip at style:campaign-site-wave:47",
+   "text[37] site:campaign-site:12 \"友24 / 予24\": text-crosses-clip at style:campaign-site-force:53",
+   "text[38] site:campaign-site:12 \"砲台あり\": text-crosses-clip at style:campaign-site-wave:55",
+   "text[39] site:campaign-site:12 \"· 補30s\": text-crosses-clip at style:campaign-site-wave:55",
+   "text[42] site:campaign-site:13 \"友24 / 予24\": text-crosses-clip at style:campaign-site-force:61",
+   "text[43] site:campaign-site:13 \"砲台あり\": text-crosses-clip at style:campaign-site-wave:63",
+   "text[44] site:campaign-site:13 \"· 補30s\": text-crosses-clip at style:campaign-site-wave:63",
+   "text[47] site:campaign-site:14 \"友24 / 予24\": text-crosses-clip at style:campaign-site-force:69",
+   "text[48] site:campaign-site:14 \"砲台あり\": text-crosses-clip at style:campaign-site-wave:71",
+   "text[49] site:campaign-site:14 \"· 補30s\": text-crosses-clip at style:campaign-site-wave:71",
+   "text[52] site:campaign-site:15 \"友24 / 予24\": text-crosses-clip at style:campaign-site-force:77",
+   "text[53] site:campaign-site:15 \"砲台あり\": text-crosses-clip at style:campaign-site-wave:79",
+   "text[54] site:campaign-site:15 \"· 補30s\": text-crosses-clip at style:campaign-site-wave:79",
+   "text[57] site:campaign-site:16 \"友24 / 予24\": text-crosses-clip at style:campaign-site-force:85",
+   "text[58] site:campaign-site:16 \"砲台あり\": text-crosses-clip at style:campaign-site-wave:87",
+   "text[59] site:campaign-site:16 \"· 補30s\": text-crosses-clip at style:campaign-site-wave:87",
+   "text[62] site:campaign-site:17 \"友24 / 予24\": text-crosses-clip at style:campaign-site-force:93",
+   "text[63] site:campaign-site:17 \"砲台あり\": text-crosses-clip at style:campaign-site-wave:95",
+   "text[64] site:campaign-site:17 \"· 補30s\": text-crosses-clip at style:campaign-site-wave:95",
+   "text-owner-collision header:hud-top:10 / header:hud-top:10",
+   "text-owner-collision site:campaign-site:11 / site:campaign-site:11",
+   "text-owner-collision site:campaign-site:12 / site:campaign-site:12",
+   "text-owner-collision site:campaign-site:13 / site:campaign-site:13",
+   "text-owner-collision site:campaign-site:14 / site:campaign-site:14",
+   "text-owner-collision site:campaign-site:15 / site:campaign-site:15",
+   "text-owner-collision site:campaign-site:16 / site:campaign-site:16",
+   "text-owner-collision site:campaign-site:17 / site:campaign-site:17",
+   "text-owner-collision control:bomb:20 / control:bomb:20",
+   "text-owner-collision control:loop:21 / control:loop:21",
+ ]
```

# Page snapshot

```yaml
- main [ref=e2]:
  - generic "7方面の地上軍を支援する航空戦闘画面" [active] [ref=e3]
  - region "飛行中の情報":
    - generic [ref=e4]:
      - generic [ref=e5]:
        - generic [ref=e6]: 作戦経過 · ノーマル
        - strong [ref=e7]: 00:00.01
      - generic "陣地占領数と残機" [ref=e8]:
        - generic [ref=e9]:
          - generic [ref=e10]: 味方の旗
          - generic [ref=e11]: "0"
          - generic [ref=e12]: / 7陣地
        - generic [ref=e13]:
          - button "音をオンにする" [ref=e14] [cursor=pointer]: 音 OFF
          - button "一時停止" [ref=e15] [cursor=pointer]: Ⅱ
        - generic [ref=e16]:
          - generic [ref=e17]: 残機
          - generic [ref=e18]: "3"
          - generic [ref=e19]: 現在機を含む
    - list "7陣地の戦況":
      - listitem "陣地1、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで30秒、敵次の補充周期まで45秒":
        - generic:
          - generic: "1"
          - generic: 敵
        - generic: 友24 / 予24
        - generic: 砲台あり · 補30s
      - listitem "陣地2、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで30秒、敵次の補充周期まで45秒":
        - generic:
          - generic: "2"
          - generic: 敵
        - generic: 友24 / 予24
        - generic: 砲台あり · 補30s
      - listitem "陣地3、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで30秒、敵次の補充周期まで45秒":
        - generic:
          - generic: "3"
          - generic: 敵
        - generic: 友24 / 予24
        - generic: 砲台あり · 補30s
      - listitem "陣地4、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで30秒、敵次の補充周期まで45秒":
        - generic:
          - generic: "4"
          - generic: 敵
        - generic: 友24 / 予24
        - generic: 砲台あり · 補30s
      - listitem "陣地5、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで30秒、敵次の補充周期まで45秒":
        - generic:
          - generic: "5"
          - generic: 敵
        - generic: 友24 / 予24
        - generic: 砲台あり · 補30s
      - listitem "陣地6、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで30秒、敵次の補充周期まで45秒":
        - generic:
          - generic: "6"
          - generic: 敵
        - generic: 友24 / 予24
        - generic: 砲台あり · 補30s
      - listitem "陣地7、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで30秒、敵次の補充周期まで45秒":
        - generic:
          - generic: "7"
          - generic: 敵
        - generic: 友24 / 予24
        - generic: 砲台あり · 補30s
    - generic [ref=e20]:
      - generic [ref=e21]:
        - text: 機体
        - generic [ref=e22]: "100"
        - generic [ref=e23]: "%"
      - generic [ref=e26]:
        - generic [ref=e27]: 300m
        - generic [ref=e28]: 396km/h
      - generic [ref=e29]: 味方兵 168 · 予備 168
      - generic [ref=e30]: 期限まで 19:59
      - generic [ref=e31]: スコア 0
      - generic "残弾数" [ref=e32]: 機銃 288 · 機関砲 96
    - paragraph
    - button "爆弾を投下・2発・落下地点の予測（予測）" [ref=e33] [cursor=pointer]:
      - generic: 爆弾
      - generic: 残り2発
      - generic: 落下地点の予測
    - paragraph: キーで操縦
    - button "宙返り すぐ使える" [ref=e34] [cursor=pointer]:
      - generic: ↻
      - generic: 宙返り
      - generic: すぐ使える
    - generic:
      - button "射撃（長押し）" [ref=e35] [cursor=pointer]: 射撃
      - slider "速度レバー" [ref=e36]:
        - generic: 加速
        - generic: 保持
        - generic: 減速
      - generic [ref=e37]: 上で加速、下で減速。離すと中央に戻り、調整した速度を保持します。フォーカス中は矢印キーで調整できます。
  - status: 7軍の進軍開始 · 砲台と竜を排除し、旗をそろえよう
```

# Test source

```ts
  2   | import { RealRendererDriver } from './real-driver';
  3   | import { assertFreshGeometry, createVisibilityPredicate } from './geometry-contract';
  4   | import { assertCaptureCancelled, type CaptureEvent } from './capture-contract';
  5   | import { collectHudTextGeometry, textGeometryIssues, type TextGeometry, type TextRegion } from './text-geometry';
  6   | import { verifyDetailScroll } from './detail-scroll';
  7   | import { detailGeometrySnapshot } from './text-geometry';
  8   | import { meetsMinimumTarget } from './geometry-contract';
  9   | import { CASES } from './acceptance-cases';
  10  | 
  11  | export async function runCase(driver: RealRendererDriver, info: TestInfo, id: string, body: () => Promise<void>) {
  12  |   const row = CASES.find(row => row[0] === id)!;
  13  |   let outcome = 'failed', backend: unknown;
  14  |   try {
  15  |     await driver.boot(); backend = await driver.backend(); await body();
  16  |     expect(driver.pageErrors).toEqual([]); expect(driver.releasedFences).toBe(driver.createdFences);
  17  |     driver.evidence.push({ label: 'case-assertions-completed', id }); outcome = 'passed';
  18  |   } finally {
  19  |     await info.attach('clean-acceptance-evidence', { contentType: 'application/json', body: JSON.stringify({
  20  |       schemaVersion: 1, id, category: row[1], classification: 'controlled-clock-functional', outcome,
  21  |       runtimeMocked: false, rendererMocked: false, applicationQueueModified: false,
  22  |       faultInjection: id === 'render-fault' ? 'Canvas2D.clearRect throws once' : id === 'frame-gap' ? 'Playwright clock fastForward(400)' : ['storage-failure','storage-session','storage-future-rollback'].includes(String(id)) ? 'Storage.setItem throws' : null,
  23  |       physicalDeviceAcceptance: 'unverified', performanceAcceptance: 'not-measured', releaseReady: false,
  24  |       backend, steps: driver.budget.steps, ownedFencesCreated: driver.createdFences,
  25  |       ownedFencesReleased: driver.releasedFences, pageErrors: driver.pageErrors, observations: driver.evidence,
  26  |     }, null, 2) });
  27  |   }
  28  | }
  29  | export async function inputAt(driver: RealRendererDriver, tick: number) {
  30  |   const audit = await driver.audit(); expect(audit.dropped).toBe(0);
  31  |   const entries = audit.entries.filter((entry: any) => entry.tick <= tick);
  32  |   expect(entries.length).toBeGreaterThan(0);
  33  |   driver.evidence.push({ label: 'consumed-input', tick, audit });
  34  |   return entries.at(-1).input;
  35  | }
  36  | export async function neutral(driver: RealRendererDriver) {
  37  |   const state = await driver.full();
  38  |   expect(state.controlsInput.keys).toEqual([]); expect(state.controlsInput.steerPointer).toBeNull();
  39  |   expect(state.controlsInput.turn).toBe(0); expect(state.controlsInput.climb).toBe(0); expect(state.controlsInput.throttle).toBe(0); expect(state.controlsInput.throttlePointer).toBeNull();
  40  |   for (const ids of Object.values(state.controlsInput.heldPointers)) expect(ids).toEqual([]);
  41  | }
  42  | export async function frozen(driver: RealRendererDriver, frames = 3) {
  43  |   const before = await driver.requireState('freeze-before'); expect(before.phase).toBe('paused');
  44  |   for (let n = 0; n < frames; n++) await driver.step();
  45  |   const after = await driver.requireState('freeze-after');
  46  |   expect(after.phase).toBe('paused'); expect(after.tick).toBe(before.tick);
  47  |   expect(after.activeTicks).toBe(before.activeTicks); expect(after.queue.submittedCount).toBe(before.queue.submittedCount);
  48  |   await neutral(driver); return after;
  49  | }
  50  | export async function liveGeometry(driver: RealRendererDriver) {
  51  |   const state = await driver.requireState('live-geometry'); expect(state.phase).toBe('playing');
  52  |   const full = await driver.full(), layout = full.render.hudLayout;
  53  |   const visibility=await driver.call('create test visibility predicate',()=>driver.page.evaluateHandle(createVisibilityPredicate));
  54  |   let dom, textGeometry:TextGeometry;
  55  |   try { dom = await driver.call('collect current live DOM geometry',()=>driver.page.evaluate((visible) => {
  56  |     const rect = (node: Element) => { const r = node.getBoundingClientRect(); return { x:r.x,y:r.y,width:r.width,height:r.height }; };
  57  |     const canvas = rect(document.querySelector('#flight')!);
  58  |     const compact=document.querySelector('#app')?.getAttribute('data-campaign-hud')==='compact';
  59  |     const panels=[...document.querySelectorAll<HTMLElement>('.flight-data > *, .hud-top .time-block, #campaign-threat, #payload-status, #reload-status, #warning, #announcement, #respawn-status, #flight-tip, #throttle-layout-note, #campaign-hud-details, #campaign-mode-status, #hud > .target-tally, #hud > #bomb-hint')]
  60  |       .filter(node=>visible(node)&&!node.parentElement?.closest('#campaign-hud-details')&&(!node.matches('.hud-top .time-block')||compact||(canvas.width<=360&&canvas.height>canvas.width)));
  61  |     const obstacles=[...document.querySelectorAll<HTMLElement>('.hud-top, #campaign-sites .campaign-site[data-site], #hud button, #hud [role="slider"]')].filter(visible);
  62  |     const nodes=[...new Set([...panels,...obstacles])];
  63  |     const local=(node:HTMLElement)=>({id:node.id||node.className,...rect(node),x:rect(node).x-canvas.x,y:rect(node).y-canvas.y});
  64  |     return { compact, canvas, viewport: {width:innerWidth,height:innerHeight}, sites:[...document.querySelectorAll('#campaign-sites .campaign-site[data-site]')].map(rect),
  65  |       panels:panels.map(local),obstacles:obstacles.map(local),
  66  |       nodes:nodes.map(node => ({id:node.id || node.className, button:node.tagName==='BUTTON'||node.getAttribute('role')==='slider', panel:panels.includes(node), scrollWidth:node.scrollWidth,clientWidth:node.clientWidth,scrollHeight:node.scrollHeight,clientHeight:node.clientHeight,...rect(node)})),
  67  |       overlays: ['home','pause-screen','result'].map(id => ({id, hidden:document.getElementById(id)!.hidden})), dpr:devicePixelRatio };
  68  |   },visibility));
  69  |     textGeometry=await driver.call('collect current full-text and clipping geometry',()=>driver.page.evaluate(collectHudTextGeometry,visibility as any));
  70  |   } finally {await visibility.dispose();}
  71  |   // Preserve independently collected current DOM even if the first assertion fails.
  72  |   driver.evidence.push({label:'live-dom-geometry-before-assertions',dom,layout});
  73  |   const reservations:TextRegion[]=[
  74  |     {key:'canvas:radar',kind:'radar',rect:layout.radar.rect},
  75  |     ...layout.obstacles.filter((r:any)=>['aim-and-reload-ring','central-flight-lane'].includes(r.id)).map((r:any)=>({key:`canvas:${r.id}`,kind:'sight-reservation',rect:r})),
  76  |     ...(layout.canvasLabels??[]).filter((r:any)=>r.rect).map((r:any)=>({key:`canvas:${r.id}`,kind:'canvas-label',rect:r.rect})),
  77  |   ].map(r=>({...r,rect:{...r.rect,x:r.rect.x+dom.canvas.x,y:r.rect.y+dom.canvas.y}}));
  78  |   const detailSnapshot=dom.compact?detailGeometrySnapshot(textGeometry):null;
  79  |   const textIssues=[...textGeometryIssues(detailSnapshot?.projected??textGeometry,reservations),...(detailSnapshot?.completenessIssues??[])];
  80  |   driver.evidence.push({label:'full-text-geometry-before-assertions',textGeometry,reservations,issues:textIssues});
  81  |   expect(layout.status).toBe('placed'); expect(layout.measurements).toBeGreaterThan(0);
  82  |   expect(full.render.sites).toBe(7); expect(full.render.calls).toBeGreaterThan(0); expect(full.render.triangles).toBeGreaterThan(0);
  83  |   // 0.75 CSS-pixel tolerance covers subpixel CSS rounding, never clipping or stale-size reuse.
  84  |   assertFreshGeometry(dom.panels, (layout.panels??[]).map((p:any)=>({...p.rect,id:p.id})), 'live panels');
  85  |   assertFreshGeometry(dom.obstacles, layout.obstacles.filter((r:any)=>!['aim-and-reload-ring','central-flight-lane'].includes(r.id)), 'live obstacles');
  86  |   expect(dom.sites).toHaveLength(7); expect(dom.overlays.every(item => item.hidden)).toBe(true);
  87  |   const boxes = [layout.radar.rect, ...(layout.panels ?? []).map((p:any) => p.rect), ...layout.obstacles,
  88  |     ...(layout.canvasLabels ?? []).filter((p:any) => p.status === 'placed').map((p:any) => p.rect)];
  89  |   const inside = (r:any) => { expect(Number.isFinite(r.x+r.y+r.width+r.height)).toBe(true); expect(r.width).toBeGreaterThan(0); expect(r.height).toBeGreaterThan(0);
  90  |     expect(r.x).toBeGreaterThanOrEqual(-1); expect(r.y).toBeGreaterThanOrEqual(-1);
  91  |     expect(r.x+r.width).toBeLessThanOrEqual(dom.canvas.width+1); expect(r.y+r.height).toBeLessThanOrEqual(dom.canvas.height+1); };
  92  |   for (const box of boxes) inside(box);
  93  |   for (const node of dom.nodes) {
  94  |     inside({...node,x:node.x-dom.canvas.x,y:node.y-dom.canvas.y});
  95  |     expect(node.x).toBeGreaterThanOrEqual(-1); expect(node.y).toBeGreaterThanOrEqual(-1);
  96  |     expect(node.x+node.width).toBeLessThanOrEqual(dom.viewport.width+1); expect(node.y+node.height).toBeLessThanOrEqual(dom.viewport.height+1);
  97  |     // Raw scroll/client metrics remain in evidence. Visible text outside its own
  98  |     // circle is judged by fragments/clipping/foreign collisions below, not by
  99  |     // an invented requirement that every label fit inside the circle.
  100 |     if(node.button) { expect(meetsMinimumTarget(node.width),`${node.id} width ${node.width}: requires 44 CSS px`).toBe(true); expect(meetsMinimumTarget(node.height),`${node.id} height ${node.height}: requires 44 CSS px`).toBe(true); }
  101 |   }
> 102 |   expect(textIssues, 'Full visible text must be complete, unclipped and unobscured').toEqual([]);
      |                                                                                      ^ Error: Full visible text must be complete, unclipped and unobscured
  103 |   const overlap = (a:any,b:any) => Math.min(a.x+a.width,b.x+b.width)-Math.max(a.x,b.x)>1 && Math.min(a.y+a.height,b.y+b.height)-Math.max(a.y,b.y)>1;
  104 |   const sight = layout.obstacles.find((r:any) => r.id === 'aim-and-reload-ring'); expect(sight).toBeTruthy();
  105 |   const siteRects = dom.sites.map(r => ({...r,x:r.x-dom.canvas.x,y:r.y-dom.canvas.y}));
  106 |   for (const r of siteRects) { inside(r); expect(overlap(r,sight)).toBe(false); expect(overlap(r,layout.radar.rect)).toBe(false); }
  107 |   for(let i=0;i<siteRects.length;i++) for(let j=i+1;j<siteRects.length;j++) expect(overlap(siteRects[i],siteRects[j])).toBe(false);
  108 |   for(const node of dom.nodes.filter(n=>n.button)) expect(overlap({...node,x:node.x-dom.canvas.x,y:node.y-dom.canvas.y},sight)).toBe(false);
  109 |   for(let i=0;i<dom.panels.length;i++) for(let j=i+1;j<dom.panels.length;j++) expect(overlap(dom.panels[i],dom.panels[j])).toBe(false);
  110 |   for(const panel of dom.panels) for(const site of siteRects) expect(overlap(panel,site)).toBe(false);
  111 |   for(const panel of layout.panels ?? []) { expect(overlap(panel.rect,sight)).toBe(false); expect(overlap(panel.rect,layout.radar.rect)).toBe(false); }
  112 |   for (const selector of ['#pause','#bomb','#loop', ...(state.mode==='normal'?['#fire','#throttle']:[])]) await driver.point(selector);
  113 |   if(dom.compact)await verifyDetailScroll(driver,reservations);
  114 |   driver.evidence.push({ label:'actual-live-dom-geometry', dom, layout }); return {dom,layout};
  115 | }
  116 | 
  117 | /** Establish actual native capture before requesting its loss; no synthetic events. */
  118 | export async function cancelNativeCapture(driver:RealRendererDriver, control:'bomb'|'loop') {
  119 |   const selector=`#${control}`, point=await driver.point(selector);
  120 |   await driver.page.locator(selector).evaluate(node=>{
  121 |     const events:Array<{type:string;pointerId:number;isTrusted:boolean;targetId:string}>=[];
  122 |     const record=(event:Event)=>{const p=event as PointerEvent;events.push({type:p.type,pointerId:p.pointerId,isTrusted:p.isTrusted,targetId:(p.currentTarget as Element).id});};
  123 |     const types=['pointerdown','gotpointercapture','lostpointercapture','pointerup'];
  124 |     for(const type of types)node.addEventListener(type,record);
  125 |     (window as any).__acceptanceCaptureObservation={events,remove:()=>{for(const type of types)node.removeEventListener(type,record);}};
  126 |   });
  127 |   try {
  128 |     await driver.page.mouse.move(point.x,point.y);await driver.page.mouse.down();
  129 |     // setPointerCapture initially sets only a pending override. This real move
  130 |     // processes it, producing gotpointercapture before release is requested.
  131 |     await driver.page.mouse.move(point.x+1,point.y);
  132 |     const active=await driver.page.locator(selector).evaluate((node,control)=>{
  133 |       const events=(window as any).__acceptanceCaptureObservation.events;
  134 |       const held=(window as any).__fantasiaReadState(false).controlsInput.heldPointers[control];
  135 |       return {events:[...events],held:[...held],captured:held.length===1&&node.hasPointerCapture(held[0])};
  136 |     },control);
  137 |     driver.evidence.push({label:'native-capture-established',control,...active});
  138 |     expect(active.captured).toBe(true);expect(active.held).toHaveLength(1);
  139 |     expect(active.events.map((e:CaptureEvent)=>e.type)).toEqual(['pointerdown','gotpointercapture']);
  140 |     for(const event of active.events as CaptureEvent[]) {expect(event.isTrusted).toBe(true);expect(event.pointerId).toBe(active.held[0]);expect(event.targetId).toBe(control);}
  141 |     await driver.page.locator(selector).evaluate((node,pointerId)=>node.releasePointerCapture(pointerId),active.held[0]);
  142 |     await driver.page.mouse.move(point.x+2,point.y);
  143 |     const cancelled=await driver.page.evaluate(control=>({events:[...(window as any).__acceptanceCaptureObservation.events],heldBeforeUp:[...(window as any).__fantasiaReadState(false).controlsInput.heldPointers[control]]}),control);
  144 |     driver.evidence.push({label:'native-capture-cancelled-before-up',control,pointerId:active.held[0],...cancelled});
  145 |     assertCaptureCancelled(cancelled.events,active.held[0],control,cancelled.heldBeforeUp);
  146 |     await driver.page.mouse.up();
  147 |   } finally {
  148 |     const observations=await driver.page.evaluate(()=>{const o=(window as any).__acceptanceCaptureObservation;const events=[...o.events];o.remove();delete (window as any).__acceptanceCaptureObservation;return events;});
  149 |     driver.evidence.push({label:'native-capture-event-sequence',control,events:observations});
  150 |   }
  151 | }
  152 | 
```