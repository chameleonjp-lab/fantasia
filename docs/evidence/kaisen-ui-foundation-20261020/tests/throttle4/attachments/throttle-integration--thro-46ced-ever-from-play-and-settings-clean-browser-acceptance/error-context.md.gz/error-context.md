# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: throttle-integration.spec.ts >> [throttle-easy] Easy preserves cruise and omits the lever from play and settings
- Location: browser-acceptance/throttle-integration.spec.ts:82:1

# Error details

```
Error: Driver operation timed out: load real app
```

# Page snapshot

```yaml
- main [ref=e2]:
  - generic "7方面の地上軍を支援する航空戦闘画面" [ref=e3]
  - region "ファンタジア" [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]: F
      - generic [ref=e7]: ZERO SERIES / TIME ATTACK
      - generic [ref=e8]: 暫定版 · 竜火球停止
    - generic [ref=e9]:
      - paragraph [ref=e10]: 剣と魔法の世界を、空から支える
      - heading "ファンタジア" [level=1] [ref=e11]
      - paragraph [ref=e12]:
        - text: 同時に進む7軍に、突破口を。
        - text: 7つの旗を、味方でそろえるまでの時間を競う。
    - generic [ref=e13]:
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: 味方地上軍
          - strong [ref=e17]: 7軍
          - emphasis [ref=e18]: 剣・弓・魔法・騎馬
        - generic [ref=e19]:
          - generic [ref=e20]: 占領目標
          - strong [ref=e21]: 7陣地
          - emphasis [ref=e22]: 全旗の同時所有で勝利
        - generic [ref=e23]:
          - generic [ref=e24]: 魔法砲台
          - strong [ref=e25]: 7基
          - emphasis [ref=e26]: 敵兵・竜は継続補填
      - group "操作モード" [ref=e27]:
        - generic [ref=e28]: 操作モード
        - generic [ref=e29] [cursor=pointer]:
          - radio "イージー" [checked] [ref=e30]
          - generic [ref=e31]: イージー
        - generic [ref=e32] [cursor=pointer]:
          - radio "ノーマル" [ref=e33]
          - generic [ref=e34]: ノーマル
      - button "画面を準備しています" [disabled] [ref=e35]
      - paragraph [ref=e36]:
        - text: 画面をドラッグして操縦
        - text: 照準円内・1.2km以内へ自動射撃 · 7方面の地上軍を支援
      - paragraph [ref=e37]: 暫定版では最速記録を保存しません（既存記録は保持）
      - generic [ref=e38]:
        - button "ルールと操作方法" [ref=e39] [cursor=pointer]
        - button "操作設定" [ref=e40] [cursor=pointer]
    - generic [ref=e41]:
      - generic [ref=e42]: FANTASIA / 7陣地占領戦
      - button "音をオンにする" [ref=e43] [cursor=pointer]
  - status
```

# Test source

```ts
  1   | import type { Page } from '@playwright/test';
  2   | import { createOwnedFence, pollOwnedFence, releaseOwnedFence } from './native-fence';
  3   | import { RunBudget } from './run-budget';
  4   | 
  5   | export interface Observed {
  6   |   phase: string; screen: string; mode: string; tick: number; activeTicks: number;
  7   |   runId: string; graphicsReady: boolean; bombs: number; status: string; startupError: string | null;
  8   |   pauseReasons: string[]; performanceInterrupted: boolean; fatalLogicError: string | null; renderStatus: string;
  9   |   preparation: { phase: string; failure: string | null };
  10  |   queue: { status: string; failure: string | null; submittedCount: number; completedCount: number };
  11  |   render: { calls: number; triangles: number; hudLayout: { status?: string; measurements: number } };
  12  | }
  13  | 
  14  | export class RealRendererDriver {
  15  |   readonly budget = new RunBudget();
  16  |   readonly evidence: Array<Record<string, unknown>> = [];
  17  |   readonly pageErrors: string[] = [];
  18  |   createdFences = 0;
  19  |   releasedFences = 0;
  20  |   constructor(readonly page: Page) { page.on('pageerror', error => this.pageErrors.push(error.message)); }
  21  | 
  22  |   async call<T>(label: string, work: () => Promise<T>, cap = 5000): Promise<T> {
  23  |     const ms = Math.min(cap, this.budget.remaining(label));
  24  |     let timer: ReturnType<typeof setTimeout>;
> 25  |     try { return await Promise.race([work(), new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error(`Driver operation timed out: ${label}`)), ms); })]); }
      |                                                                                                                  ^ Error: Driver operation timed out: load real app
  26  |     finally { clearTimeout(timer!); }
  27  |   }
  28  |   async read(): Promise<Observed | null> {
  29  |     return this.call('read existing observation', () => this.page.evaluate(() => {
  30  |       const read = (window as any).__fantasiaReadState;
  31  |       if (typeof read !== 'function') return null;
  32  |       const value = read(false);
  33  |       return { phase: value.phase, screen: value.screen, mode: value.mode, tick: value.tick,
  34  |         activeTicks: value.activeTicks, runId: value.campaign.runId, graphicsReady: value.graphicsReady,
  35  |         bombs: value.campaignPlayer.bombs, status: value.status, pauseReasons: value.pauseReasons, performanceInterrupted: value.performanceInterrupted,
  36  |         startupError: document.querySelector<HTMLElement>('#startup-error')?.hidden === false
  37  |           ? document.querySelector('#startup-error')!.textContent : null,
  38  |         fatalLogicError: value.fatalLogicError, renderStatus: value.renderStatus,
  39  |         preparation: value.startPreparation, queue: value.render?.queue,
  40  |         render: { calls: value.render?.calls, triangles: value.render?.triangles, hudLayout: value.render?.hudLayout } };
  41  |     }));
  42  |   }
  43  |   async requireState(label: string): Promise<Observed> {
  44  |     const value = await this.read();
  45  |     if (!value) throw new Error(`${label}: observation unavailable`);
  46  |     if (value.startupError || value.fatalLogicError || value.queue?.failure || this.pageErrors.length) throw new Error(`${label}: application/native renderer error`);
  47  |     this.evidence.push({ label, ...value }); return value;
  48  |   }
  49  |   async boot(): Promise<void> {
  50  |     // Pause before loading the app. Native GPU work is never replaced by the clock.
  51  |     await this.call('install test clock', () => this.page.clock.install({ time: '2026-01-01T00:00:00Z' }));
  52  |     await this.call('pause test clock', () => this.page.clock.pauseAt('2026-01-01T00:00:01Z'));
  53  |     await this.call('load real app', () => this.page.goto('/', { waitUntil: 'load', timeout: 10000 }), 10000);
  54  |     for (let frame = 0; frame < 80; frame++) {
  55  |       const state = await this.read();
  56  |       if (state) this.evidence.push({ label: 'boot-observation', ...state });
  57  |       if (state?.startupError || state?.fatalLogicError || state?.queue?.failure || this.pageErrors.length) throw new Error('Real application/renderer failed during boot');
  58  |       if (state?.graphicsReady) {
  59  |         if (state.phase !== 'ready' || state.tick !== 0) throw new Error('Boot advanced gameplay before Start');
  60  |         await this.requireState('home-ready'); return;
  61  |       }
  62  |       await this.step();
  63  |     }
  64  |     throw new Error('Renderer preparation did not complete within the bounded proof');
  65  |   }
  66  |   async drainNativeGpu(): Promise<void> {
  67  |     const owned = await this.call('create test fence', () => this.page.evaluateHandle(createOwnedFence));
  68  |     this.createdFences++;
  69  |     let originalError: unknown, failed = false;
  70  |     try {
  71  |       const deadline = Math.min(Date.now() + 15000, this.budget.deadline);
  72  |       while (Date.now() < deadline) {
  73  |         const status = await this.call('poll test fence', () => owned.evaluate(pollOwnedFence));
  74  |         if (status === 'ready') return;
  75  |         // Runner timer, not page time. No busy/blocking GL wait or app queue reset.
  76  |         await new Promise(resolve => setTimeout(resolve, 20));
  77  |       }
  78  |       throw new Error('Real GPU did not complete within the wall-clock deadline');
  79  |     } catch (error) { failed = true; originalError = error; throw error; }
  80  |     finally {
  81  |       try {
  82  |         // Cleanup still gets a bounded attempt after the driver budget expires.
  83  |         let timer: ReturnType<typeof setTimeout>;
  84  |         try {
  85  |           await Promise.race([owned.evaluate(releaseOwnedFence), new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new Error('Test fence cleanup timed out')), 1000); })]);
  86  |           this.releasedFences++;
  87  |         } finally { clearTimeout(timer!); }
  88  |       } catch (error) {
  89  |         this.evidence.push({ cleanupError: String(error), contextTeardownRequired: true });
  90  |         if (!failed) throw error;
  91  |       } finally {
  92  |         // Playwright closes the test context on failure, reclaiming native resources.
  93  |         void owned.dispose().catch(() => {});
  94  |         if (failed) this.evidence.push({ operationError: String(originalError) });
  95  |       }
  96  |     }
  97  |   }
  98  |   async step(): Promise<void> {
  99  |     this.budget.step(); await this.drainNativeGpu();
  100 |     await this.call('advance one controlled animation step', () => this.page.clock.runFor(16));
  101 |   }
  102 |   async reachPlaying(): Promise<Observed> {
  103 |     for (let frame = 0; frame < 40; frame++) {
  104 |       const state = await this.requireState('preparation-observation');
  105 |       if (state.phase === 'playing') {
  106 |         if (state.tick !== 0 || state.activeTicks !== 0) throw new Error('Selected start did not commit at tick zero');
  107 |         return state;
  108 |       }
  109 |       if (state.phase !== 'preparing' || state.preparation.failure) throw new Error('Unexpected state while waiting for selected preparation');
  110 |       await this.step();
  111 |     }
  112 |     throw new Error('Selected preparation exceeded the bounded proof');
  113 |   }
  114 |   async nextTick(): Promise<Observed> {
  115 |     const initial = await this.requireState('before-input-tick');
  116 |     if (initial.phase !== 'playing') throw new Error('Input check requires actual playing state');
  117 |     for (let frame = 0; frame < 4; frame++) {
  118 |       await this.step(); const state = await this.requireState('input-tick');
  119 |       if (state.phase !== 'playing') throw new Error('Unexpected stop in controlled-clock functional proof');
  120 |       if (state.tick > initial.tick) {
  121 |         if (state.tick !== initial.tick + 1) throw new Error('Driver did not isolate exactly one simulation tick');
  122 |         return state;
  123 |       }
  124 |     }
  125 |     throw new Error('Real simulation did not consume the bounded input tick');
```