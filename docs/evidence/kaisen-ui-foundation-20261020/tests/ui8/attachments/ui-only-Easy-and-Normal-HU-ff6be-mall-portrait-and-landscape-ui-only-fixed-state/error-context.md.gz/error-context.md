# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: ui-only.spec.ts >> Easy and Normal HUD, seven sites, aim geometry and alerts fit small portrait and landscape
- Location: browser-ui-only/ui-only.spec.ts:1452:1

# Error details

```
Test timeout of 12000ms exceeded.
```