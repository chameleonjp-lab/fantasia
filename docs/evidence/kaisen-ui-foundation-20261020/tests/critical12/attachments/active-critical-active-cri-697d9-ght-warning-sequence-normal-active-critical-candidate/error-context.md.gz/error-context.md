# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: active-critical.spec.ts >> active-critical-small-portrait >> flight-warning-sequence-normal
- Location: browser-acceptance/active-critical.spec.ts:16:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 6

- Array []
+ Array [
+   "remaining-time: critical item moved into scrolling details",
+   "mg-ammo: critical item moved into scrolling details",
+   "cannon-ammo: critical item moved into scrolling details",
+   "campaign-threat: critical item moved into scrolling details",
+ ]
```

# Page snapshot

```yaml
- main [ref=e2]:
  - generic "7方面の地上軍を支援する航空戦闘画面" [active] [ref=e3]
  - region "飛行中の情報":
    - generic "陣地占領数と残機" [ref=e5]:
      - generic [ref=e6]:
        - button "音をオンにする" [ref=e7] [cursor=pointer]: 音 OFF
        - button "一時停止" [ref=e8] [cursor=pointer]: Ⅱ
    - list "7陣地の戦況":
      - listitem "陣地1、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで25秒、敵次の補充周期まで40秒":
        - generic:
          - generic: "1"
          - generic: 敵
        - generic: 砲台あり
      - listitem "陣地2、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで25秒、敵次の補充周期まで40秒":
        - generic:
          - generic: "2"
          - generic: 敵
        - generic: 砲台あり
      - listitem "陣地3、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで25秒、敵次の補充周期まで40秒":
        - generic:
          - generic: "3"
          - generic: 敵
        - generic: 砲台あり
      - listitem "陣地4、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで25秒、敵次の補充周期まで40秒":
        - generic:
          - generic: "4"
          - generic: 敵
        - generic: 砲台あり
      - listitem "陣地5、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで25秒、敵次の補充周期まで40秒":
        - generic:
          - generic: "5"
          - generic: 敵
        - generic: 砲台あり
      - listitem "陣地6、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで25秒、敵次の補充周期まで40秒":
        - generic:
          - generic: "6"
          - generic: 敵
        - generic: 砲台あり
      - listitem "陣地7、敵所有、砲台あり、占領進捗0%、味方地上兵24、敵地上兵24、予備兵24、砲台HP600、味方次の補充周期まで25秒、敵次の補充周期まで40秒":
        - generic:
          - generic: "7"
          - generic: 敵
        - generic: 砲台あり
    - generic [ref=e9]:
      - generic [ref=e10]:
        - text: 機体
        - generic [ref=e11]: "100"
        - generic [ref=e12]: "%"
      - generic [ref=e15]:
        - generic [ref=e16]: 300m
        - generic [ref=e17]: 396km/h
    - paragraph
    - button "爆弾を投下・2発・落下地点の予測（予測）" [ref=e18] [cursor=pointer]:
      - generic: 爆弾
      - generic: 残り2発
    - button "宙返り" [ref=e19] [cursor=pointer]:
      - generic: ↻
      - generic: 宙返り
    - generic:
      - button "射撃（長押し）" [ref=e20] [cursor=pointer]: 射撃
      - slider "速度レバー" [ref=e21]:
        - generic: 加速
        - generic: 保持
        - generic: 減速
      - generic [ref=e22]: 上で加速、下で減速。離すと中央に戻り、調整した速度を保持します。フォーカス中は矢印キーで調整できます。
    - region "飛行・戦況の詳細（スクロール）" [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]: 作戦経過 ·
        - strong [ref=e26]: 00:05.23
      - generic [ref=e27]:
        - generic [ref=e28]: 味方の旗
        - generic [ref=e29]: "0"
        - generic [ref=e30]: / 7陣地
      - generic [ref=e31]: 味方兵 168 · 予備 168
      - generic [ref=e32]: スコア 0
      - generic [ref=e33]: 期限まで 19:54
      - generic "残弾数" [ref=e34]: 機銃 288 · 機関砲 96
      - status: 砲台の魔法 · 自機を照準中 · 陣地1 · 1.2秒 · ほか2
      - status
      - paragraph: キーで操縦
      - generic [ref=e35]: すぐ使える
      - generic [ref=e36]: 現在機を含む
      - generic [ref=e37]: 落下地点の予測
      - region "陣地1の詳細" [ref=e38]:
        - text: 陣地1
        - generic [ref=e39]: 友24 / 予24
        - generic [ref=e40]: · 補25s
      - region "陣地2の詳細" [ref=e41]:
        - text: 陣地2
        - generic [ref=e42]: 友24 / 予24
        - generic [ref=e43]: · 補25s
      - region "陣地3の詳細" [ref=e44]:
        - text: 陣地3
        - generic [ref=e45]: 友24 / 予24
        - generic [ref=e46]: · 補25s
      - region "陣地4の詳細" [ref=e47]:
        - text: 陣地4
        - generic [ref=e48]: 友24 / 予24
        - generic [ref=e49]: · 補25s
      - region "陣地5の詳細" [ref=e50]:
        - text: 陣地5
        - generic [ref=e51]: 友24 / 予24
        - generic [ref=e52]: · 補25s
      - region "陣地6の詳細" [ref=e53]:
        - text: 陣地6
        - generic [ref=e54]: 友24 / 予24
        - generic [ref=e55]: · 補25s
      - region "陣地7の詳細" [ref=e56]:
        - text: 陣地7
        - generic [ref=e57]: 友24 / 予24
        - generic [ref=e58]: · 補25s
    - generic [ref=e59]: ノーマル
    - generic [ref=e60]:
      - generic [ref=e61]: 残機
      - generic [ref=e62]: "3"
```

# Test source

```ts
  78  |         expect(last.controlsInput.climb).toBeLessThanOrEqual(.45);
  79  |         boundaryPiloting = { type: 'native-canvas-stick', dragY: -16, input: last.controlsInput };
  80  |       }
  81  |     }
  82  |     for (let frame = 0; frame < 1800; frame++) {
  83  |       if (criticalStateActive(kind, last)) {
  84  |         // Present persistent conditions in a fresh real renderer frame before
  85  |         // handing over to the unchanged display driver. Bomb events use their
  86  |         // original one-frame probe so an edge cannot disappear between reads.
  87  |         if (kind !== 'bomb-announcement') {
  88  |           await d.stepOne(); last = await d.full();
  89  |           if (!criticalStateActive(kind, last)) continue;
  90  |         }
  91  |         const event = last.campaign.events.find((e: any) => e.kind === 'shot' && e.weapon === 'bomb' && e.sourceRef?.id === last.campaign.player.id);
  92  |         const witness: CriticalWitness = { kind, runId: last.campaign.runId, tick: last.tick, activeTicks: last.activeTicks, ...(event ? { eventId: event.id } : {}) };
  93  |         reached = true;
  94  |         d.evidence.push({ label: 'critical-native-acquisition', kind, frames: d.budget.steps, probes: frame, key, boundaryPiloting, before: criticalRuntimeEvidence(before), reached: criticalRuntimeEvidence(last), witness, audit: await d.audit() });
  95  |         expect(last.performanceInterrupted).toBe(false); expect(last.fatalLogicError).toBeNull(); expect(d.pageErrors).toEqual([]);
  96  |         return witness;
  97  |       }
  98  |       if (last.phase === 'respawning' && down) { await d.page.keyboard.up(key!); down = false; }
  99  |       if (pointerDown) {
  100 |         expect(last.controlsInput.steerPointer).not.toBeNull();
  101 |         expect(Math.abs(last.controlsInput.turn)).toBeLessThan(.001);
  102 |         expect(last.controlsInput.climb).toBeGreaterThanOrEqual(.35);
  103 |         expect(last.controlsInput.climb).toBeLessThanOrEqual(.45);
  104 |       }
  105 |       if (!['playing', 'respawning'].includes(last.phase)) throw new Error(`Critical acquisition interrupted: ${kind}, phase=${last.phase}`);
  106 |       if (last.phase === 'respawning' && !['respawning', 'protection'].includes(kind)) throw new Error(`Critical acquisition lost aircraft before ${kind}`);
  107 |       if (kind === 'bomb-announcement') await d.stepOne(); else await d.step();
  108 |       last = await d.full();
  109 |       if (last.fatalLogicError || last.performanceInterrupted || last.render?.queue?.failure || d.pageErrors.length) throw new Error(`Critical acquisition encountered a runtime/native-renderer failure: ${kind}`);
  110 |     }
  111 |     throw new Error(`Critical state not naturally reached within 1800 frames: ${kind}`);
  112 |   } finally {
  113 |     if (pointerDown) await d.page.mouse.up();
  114 |     if (down) await d.page.keyboard.up(key!);
  115 |     d.evidence.push({ label: 'critical-acquisition-final-state', kind, ...(reached ? {} : { state: criticalRuntimeEvidence(last) }), steps: d.budget.steps });
  116 |   }
  117 | }
  118 | 
  119 | /** Read-only atomic scene + DOM + renderer evidence. No warning node or game
  120 |  * state is synthesized, and no live node is reparented by this collector. */
  121 | async function capture(d: RealRendererDriver) {
  122 |   const visible = await d.page.evaluateHandle(createVisibilityPredicate);
  123 |   const collect = await d.page.evaluateHandle(`(${collectHudTextGeometry.toString()})`);
  124 |   const project = await d.page.evaluateHandle(`(${criticalRuntimeEvidence.toString()})`);
  125 |   try {
  126 |     return await d.call('atomic active-critical DOM and scene', () => d.page.evaluate(({ visible, collect, project }) => {
  127 |       const raw = (window as any).__fantasiaReadState(false), geometry = collect(visible);
  128 |       const canvas = document.querySelector('#flight')!.getBoundingClientRect();
  129 |       const compact = document.querySelector('#app')?.getAttribute('data-campaign-hud') === 'compact';
  130 |       const panels = [...document.querySelectorAll<HTMLElement>('.flight-data > *, .hud-top .time-block, #campaign-threat, #payload-status, #reload-status, #warning, #announcement, #respawn-status, #flight-tip, #campaign-hud-details, #campaign-mode-status, #hud > .target-tally, #hud > #bomb-hint')]
  131 |         .filter(n => visible(n) && !n.parentElement?.closest('#campaign-hud-details') && (!n.matches('.hud-top .time-block') || compact || (canvas.width <= 360 && canvas.height > canvas.width)));
  132 |       const obstacles = [...document.querySelectorAll<HTMLElement>('.hud-top, #campaign-sites .campaign-site[data-site], #hud button, #hud [role="slider"], #hud [data-flight-control]')].filter(visible);
  133 |       const local = (n: HTMLElement) => { const r = n.getBoundingClientRect(); return { id: n.id || n.className, x: r.x - canvas.x, y: r.y - canvas.y, width: r.width, height: r.height }; };
  134 |       const controls = [...document.querySelectorAll<HTMLElement>('#hud button, #hud [role="slider"], #hud [data-flight-control]')].filter(visible);
  135 |       const targets = [...new Set(controls)].map(n => {
  136 |         const r = n.getBoundingClientRect(), hit = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
  137 |         return { id: n.id, role: n.getAttribute('role'), disabled: (n as HTMLButtonElement).disabled === true, inDetails: !!n.closest('#campaign-hud-details'),
  138 |           x: r.x, y: r.y, width: r.width, height: r.height, hit: !!hit && n.contains(hit) };
  139 |       });
  140 |       return { raw: project(raw), geometry, compact, targets, panels: panels.map(local), obstacles: [...new Set(obstacles)].map(local), canvas: { x: canvas.x, y: canvas.y, width: canvas.width, height: canvas.height },
  141 |         sites: [...document.querySelectorAll<HTMLElement>('#campaign-sites [data-site]')].map(n => { const r = n.getBoundingClientRect(); return { number: n.dataset.site, owner: n.dataset.owner, ownerText: n.querySelector('.campaign-site-owner')?.textContent ?? '', stateText: n.querySelector('.campaign-site-state')?.textContent ?? '', visible: visible(n), inDetails: !!n.closest('#campaign-hud-details'), x: r.x, y: r.y, width: r.width, height: r.height }; }),
  142 |         scroll: { x: scrollX, y: scrollY, app: document.querySelector('#app')!.scrollTop, hud: document.querySelector('#hud')!.scrollTop } };
  143 |     }, { visible, collect, project } as any));
  144 |   } finally { await project.dispose(); await collect.dispose(); await visible.dispose(); }
  145 | }
  146 | 
  147 | export async function verifyActiveCritical(d: RealRendererDriver, witness: CriticalWitness) {
  148 |   const first = await capture(d), kind = witness.kind;
  149 |   const required = { ...Object.fromEntries((kind === 'respawning' ? ['hud-mode', 'lives-count'] : FIXED_INSTRUMENTS).map(id => [id, ''])), ...criticalText(kind, first.raw.campaign) };
  150 |   const validate = (value: typeof first) => {
  151 |     const { raw, geometry, canvas } = value, layout = raw.render.hudLayout;
  152 |     expect(criticalStateActive(kind, raw, witness), `${kind}: source state must remain active`).toBe(true);
  153 |     expect(layout.status).toBe('placed');
  154 |     assertFreshGeometry(value.panels, (layout.panels ?? []).map((p: any) => ({ id: p.id, ...p.rect })), 'active critical panels');
  155 |     assertFreshGeometry(value.obstacles, layout.obstacles.filter((r: any) => !['aim-and-reload-ring', 'central-flight-lane'].includes(r.id)), 'active critical obstacles'); expect(raw.render.calls).toBeGreaterThan(0); expect(raw.render.triangles).toBeGreaterThan(0);
  156 |     expect(value.sites.map(s => s.number).sort()).toEqual(['1', '2', '3', '4', '5', '6', '7']);
  157 |     expect(value.sites.every(s => s.visible && !s.inDetails && s.stateText.trim())).toBe(true);
  158 |     expect(raw.render.sites).toBe(7);
  159 |     for (const site of value.sites) {
  160 |       const source = raw.campaign.sites.find((s: any) => s.id + 1 === Number(site.number));
  161 |       expect(source).toBeTruthy(); expect(site.owner).toBe(source.owner);
  162 |       expect(site.ownerText).toContain(({ friendly: '味方', enemy: '敵', neutral: '中立' } as Record<string, string>)[source.owner]);
  163 |     }
  164 |     expect(Object.values(value.scroll).every(v => v === 0)).toBe(true);
  165 |     const sight = layout.obstacles.find((r: any) => r.id === 'aim-and-reload-ring'); expect(sight).toBeTruthy();
  166 |     const overlap = (a: any, b: any) => Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x) > .75 && Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y) > .75;
  167 |     const inside = (r: any) => { expect([r.x, r.y, r.width, r.height].every(Number.isFinite)).toBe(true); expect(r.width).toBeGreaterThan(0); expect(r.height).toBeGreaterThan(0);
  168 |       expect(r.x).toBeGreaterThanOrEqual(-.75); expect(r.y).toBeGreaterThanOrEqual(-.75); expect(r.x + r.width).toBeLessThanOrEqual(canvas.width + .75); expect(r.y + r.height).toBeLessThanOrEqual(canvas.height + .75); };
  169 |     inside(sight); inside(layout.radar.rect);
  170 |     const siteRects = value.sites.map(s => ({ ...s, x: s.x - canvas.x, y: s.y - canvas.y }));
  171 |     for (const r of siteRects) { inside(r); expect(overlap(r, sight)).toBe(false); expect(overlap(r, layout.radar.rect)).toBe(false); }
  172 |     for (let i = 0; i < siteRects.length; i++) for (let j = i + 1; j < siteRects.length; j++) expect(overlap(siteRects[i], siteRects[j])).toBe(false);
  173 |     const reservations: TextRegion[] = [{ key: 'canvas:radar', kind: 'radar', rect: layout.radar.rect },
  174 |       ...layout.obstacles.filter((r: any) => ['aim-and-reload-ring', 'central-flight-lane'].includes(r.id)).map((r: any) => ({ key: `canvas:${r.id}`, kind: 'sight-reservation', rect: r })),
  175 |       ...(layout.canvasLabels ?? []).filter((r: any) => r.rect).map((r: any) => ({ key: `canvas:${r.id}`, kind: 'canvas-label', rect: r.rect }))]
  176 |       .map(r => ({ ...r, rect: { ...r.rect, x: r.rect.x + canvas.x, y: r.rect.y + canvas.y } }));
  177 |     const projected = value.compact ? detailGeometrySnapshot(geometry) : null;
> 178 |     expect(fixedCriticalTextIssues(geometry, required)).toEqual([]);
      |                                                         ^ Error: expect(received).toEqual(expected) // deep equality
  179 |     expect([...(projected?.completenessIssues ?? []), ...textGeometryIssues(projected?.projected ?? geometry, reservations)]).toEqual([]);
  180 |     if (kind !== 'respawning') {
  181 |       for (const id of ['pause', 'bomb', 'loop', ...(raw.mode === 'normal' ? ['fire', 'throttle'] : [])]) expect(value.targets.some(t => t.id === id && !t.disabled)).toBe(true);
  182 |       for (const t of value.targets.filter(t => !t.disabled)) {
  183 |         const local = { x: t.x - canvas.x, y: t.y - canvas.y, width: t.width, height: t.height };
  184 |         expect(Math.min(local.x + local.width, sight.x + sight.width) - Math.max(local.x, sight.x) > .75 && Math.min(local.y + local.height, sight.y + sight.height) - Math.max(local.y, sight.y) > .75, `${t.id} overlaps the actual sight`).toBe(false);
  185 |         expect(t.inDetails).toBe(false); expect(t.hit, `${t.id} must have an unobscured native hit target`).toBe(true);
  186 |         expect(meetsMinimumTarget(t.width) && meetsMinimumTarget(t.height)).toBe(true);
  187 |         expect(t.x).toBeGreaterThanOrEqual(-.75); expect(t.y).toBeGreaterThanOrEqual(-.75);
  188 |         expect(t.x + t.width).toBeLessThanOrEqual(geometry.viewport.width + .75); expect(t.y + t.height).toBeLessThanOrEqual(geometry.viewport.height + .75);
  189 |       }
  190 |     }
  191 |     return reservations;
  192 |   };
  193 |   d.evidence.push({ label: 'active-critical-before', witness, ...first });
  194 |   const reservations = validate(first);
  195 |   if (first.compact) {
  196 |     await verifyDetailScroll(d, reservations, kind === 'respawning' ? 'respawning' : 'playing');
  197 |     const samples = d.evidence.filter(e => e.label === 'detail-scroll-snapshot');
  198 |     expect(samples.length).toBeGreaterThan(3);
  199 |     for (const sample of samples) {
  200 |       expect(activeSampleIssues(kind, sample)).toEqual([]);
  201 |       expect(fixedCriticalTextIssues(sample.geometry as any, required)).toEqual([]);
  202 |     }
  203 |   }
  204 |   const last = await capture(d); d.evidence.push({ label: 'active-critical-after', witness, ...last }); validate(last);
  205 |   expect(d.pageErrors).toEqual([]); expect(d.createdFences).toBe(d.releasedFences);
  206 |   d.evidence.push({ label: 'active-critical-proof-completed', kind, detailTraversal: first.compact, phase: last.raw.phase });
  207 | }
  208 | 
```