import {defineConfig} from 'vite';
import original from '../scripts/vite.ui-only.config';
export default defineConfig({...original,cacheDir:'/tmp/fantasia-pr23-ui-cold-green-20261020'});
