/** Preserve Kaisen's saved hit targets when enlarged labels no longer fit.
 * The original live labels remain visible beside their control; they are not
 * shortened, scaled or added to the scrolling details. */
export class CampaignControlCaptions {
  readonly nodes: HTMLElement[] = [];
  private readonly entries: Array<{
    button: HTMLElement; label: HTMLElement; anchor: Comment; caption: HTMLElement;
    key: string; outside: boolean;
    owned: Array<{ name: string; value: string; priority: string; applied: string }>;
  }> = [];
  constructor(private readonly app: HTMLElement) {
    for (const [id, selector] of [['loop', 'b'], ['bomb', '#bomb-ammo']] as const) {
      const button = app.querySelector<HTMLElement>(`#${id}`);
      const label = button?.querySelector<HTMLElement>(selector);
      if (!button || !label) continue;
      if (id === 'loop') button.setAttribute('aria-label', '宙返り');
      const anchor = app.ownerDocument.createComment('control caption position');
      label.before(anchor);
      const caption = app.ownerDocument.createElement('div');
      caption.id = `campaign-${id}-caption`;
      caption.className = 'campaign-control-caption'; caption.hidden = true;
      app.querySelector('#hud')!.append(caption); this.nodes.push(caption);
      this.entries.push({ button, label, anchor, caption, key: '', outside: false, owned: [] });
    }
  }
  sync() {
    const win = this.app.ownerDocument.defaultView!;
    for (const entry of this.entries) {
      const { button, label, caption, anchor } = entry;
      const box = button.getBoundingClientRect(), style = win.getComputedStyle(button);
      if (!box.width || !box.height || style.display === 'none') { caption.hidden = true; continue; }
      const font = win.getComputedStyle(label);
      const key = [win.innerWidth, win.innerHeight, box.width, box.height, style.fontSize,
        font.fontSize, this.app.dataset.campaignHud].join(':');
      if (entry.key !== key) {
        if (entry.outside) {
          anchor.after(label);
          for (const owned of entry.owned) {
            if (label.style.getPropertyValue(owned.name) !== owned.applied
              || label.style.getPropertyPriority(owned.name) === 'important') continue;
            if (owned.value) label.style.setProperty(owned.name, owned.value, owned.priority);
            else label.style.removeProperty(owned.name);
          }
        }
        button.removeAttribute('data-caption-outside');
        const outside = button.scrollWidth > button.clientWidth + 1 || button.scrollHeight > button.clientHeight + 1;
        entry.outside = outside;
        if (outside) {
          const computed = win.getComputedStyle(label);
          entry.owned = ['font-size', 'line-height', 'letter-spacing'].map(name => ({
            name, value: label.style.getPropertyValue(name), priority: label.style.getPropertyPriority(name),
            applied: computed.getPropertyValue(name),
          }));
          for (const owned of entry.owned) if (owned.priority !== 'important') label.style.setProperty(owned.name, owned.applied);
          caption.append(label); button.dataset.captionOutside = 'true';
        }
        entry.key = key;
      }
      caption.hidden = !entry.outside;
      if (!entry.outside) continue;
      const size = caption.getBoundingClientRect();
      const x = Math.max(8, Math.min(box.x + (box.width - size.width) / 2, win.innerWidth - size.width - 8));
      const y = box.y >= size.height + 12 ? box.y - size.height - 4 : box.bottom + 4;
      caption.style.left = `${x}px`; caption.style.top = `${y}px`;
    }
  }
  dispose() {
    for (const { button, label, anchor, caption, owned } of this.entries) {
      anchor.after(label); anchor.remove(); caption.remove(); button.removeAttribute('data-caption-outside');
      for (const item of owned) {
        if (label.style.getPropertyValue(item.name) !== item.applied || label.style.getPropertyPriority(item.name) === 'important') continue;
        if (item.value) label.style.setProperty(item.name, item.value, item.priority); else label.style.removeProperty(item.name);
      }
    }
  }
}
