import { expect as browserExpect } from '@playwright/test';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { transpileModule, ScriptTarget, ModuleKind } from 'typescript';
import test from 'node:test';
import assert from 'node:assert/strict';
import { CampaignHudDetails } from '../src/campaign-hud-details';
import { campaignHudContextStyleChanged, measureCampaignHudMode, type HudMeasurement } from '../src/campaign-hud-layout';

const measurement: HudMeasurement = { canvas: { x: 0, y: 0, width: 800, height: 600 },
  bounds: { x: 8, y: 8, width: 784, height: 584 }, obstacles: [], panels: [], flightData: null, threat: null };
const sight = { x: 350, y: 250, width: 100, height: 100 };

test('stable compact live remeasure never probes full mode, including a newly visible critical warning', () => {
  const calls: boolean[] = [];
  const critical = { ...measurement, movableControls: [], panels: [{ id: 'warning', x: 10, y: 100, width: 200, height: 60 }] };
  const actual = measureCampaignHudMode(true, false, sight, compact => { calls.push(compact); return critical; }, () => { throw Error('must not probe hidden full content'); });
  assert.deepEqual(calls, [true]); assert.equal(actual, critical);
  assert.equal(actual.panels![0].height, 60, 'all live critical dimensions still propagate to packing');
});
test('explicit viewport, mode or typography review can leave compact when full content fits', () => {
  const calls: boolean[] = [];
  const actual = measureCampaignHudMode(true, true, sight, compact => { calls.push(compact); return measurement; }, () => false);
  assert.deepEqual(calls, [false]); assert.equal(actual, measurement);
});
test('a full-mode candidate with clipped text or blocked full-size reservation returns to compact', () => {
  for (const clip of [true, false]) {
    const calls: boolean[] = [];
    const compactMeasurement = { ...measurement, movableControls: [] };
    const full = clip ? measurement : { ...measurement, panels: [{ id: 'warning', x: 8, y: 8, width: 900, height: 50 }] };
    const actual = measureCampaignHudMode(true, true, sight, compact => { calls.push(compact); return compact ? compactMeasurement : full; }, () => clip);
    assert.deepEqual(calls, [false, true]); assert.equal(actual, compactMeasurement);
  }
});
test('ordinary full mode still checks all current content and may enter compact', () => {
  const calls: boolean[] = [];
  measureCampaignHudMode(false, false, sight, compact => { calls.push(compact); return measurement; }, () => true);
  assert.deepEqual(calls, [false, true]);
});
test('font and custom-control context changes differ from live HP, progress and reload geometry', () => {
  for (const [before, after] of [
    ['font-size:9px','font-size:18px!important'], ['line-height:1','line-height:1.3'],
    ['--control-size:44px','--control-size:88px'], ['font-family:serif','font-family:system-ui'],
    ['--safe-top:0px','--safe-top:20px'],
  ]) assert.equal(campaignHudContextStyleChanged(before, after), true);
  for (const [before, after] of [
    ['width:100%','width:99%'], ['left:10px;top:50px','left:11px;top:51px'],
    ['font-size:18px;color:red','color:blue; font-size:18px'],
    ['--campaign-hud-x:1px','--campaign-hud-x:2px'], [null, 'width:42%'],
  ]) assert.equal(campaignHudContextStyleChanged(before, after), false);
});
test('stable compact remeasure never writes scrollTop or refocuses, preserving native scrolling ownership', () => {
  const details = Object.create(CampaignHudDetails.prototype) as any;
  let scrollWrites = 0, focuses = 0;
  const active = { focus() { focuses++; } };
  details.compact = true; details.reparentRevision = 4;
  details.viewport = { set scrollTop(_value: number) { scrollWrites++; }, contains: () => true, focus() { focuses++; } };
  for (let i = 0; i < 20; i++) details.restoreReading(4, 120, active);
  assert.equal(scrollWrites, 0); assert.equal(focuses, 0);
  details.reparentRevision++;
  details.restoreReading(4, 120, active);
  assert.equal(scrollWrites, 1); assert.equal(focuses, 1, 'actual structural change repairs the former owner');
});
test('an actual return to full mode transfers reading focus to pause without injecting scroll', () => {
  const details = Object.create(CampaignHudDetails.prototype) as any;
  let scrollWrites = 0, pauseFocus = 0;
  details.compact = false; details.reparentRevision = 5;
  details.viewport = { set scrollTop(_value: number) { scrollWrites++; } };
  details.app = { querySelector(selector: string) { assert.equal(selector, '#pause'); return { focus() { pauseFocus++; } }; } };
  details.restoreReading(4, 120, {});
  assert.equal(scrollWrites, 0); assert.equal(pauseFocus, 1);
});

test('same-mode sync does not toggle visibility and restoring an already-anchored node does not reparent it', () => {
  const details = Object.create(CampaignHudDetails.prototype) as any;
  let visibilityWrites = 0, reparents = 0;
  details.compact = true; details.reparentRevision = 3;
  details.app = { dataset: { campaignHud: 'compact' }, querySelector: () => null, querySelectorAll: () => [] };
  details.viewport = details.mode = { set hidden(_value: boolean) { visibilityWrites++; } };
  details.lives = null; details.entries = new Map(); details.typography = new Map();
  details.sync(true); details.sync(true);
  assert.equal(visibilityWrites, 0); assert.equal(details.layoutRevision, 3);
  const node = {}, anchor = { parentNode: {}, nextSibling: node, after() { reparents++; } };
  details.anchors = new Map([[node, anchor]]); details.attributes = new Map();
  details.restore(node);
  assert.equal(reparents, 0); assert.equal(details.layoutRevision, 3);
});

// Run the real browser inspector against deterministic DOM geometry. This is
// a contract regression, not a replacement for browser/layout acceptance.
async function inspectReadoutContract(change: 'none' | 'fixed-in-details' | 'secondary-outside' | 'clipped-fixed' | 'duplicate-fixed' | 'stale-ammo' | 'stale-reload' | 'stale-time' | 'dormant-reload' | 'false-protection' | 'stale-threat-time' | 'stale-threat-site' | 'stale-threat-generation' | 'hidden-child' | 'collapsed-indentation' | 'preserved-whitespace' | 'unmeasurable-nbsp' | 'unmeasurable-mixed-text' | 'mode-reparent' | 'missing-mode' | 'wrong-mode' | 'duplicate-mode' | 'hidden-mode' | 'actual-protection' | 'protection-stale' | 'protection-no-attack' | 'protection-hidden' = 'none') {
  const source = readFileSync(new URL('../browser-ui-only/ui-only.spec.ts', import.meta.url), 'utf8');
  const registry = source.slice(source.indexOf('const SECONDARY_HUD_READOUTS ='), source.indexOf('async function captureSecondaryHudOriginals'));
  const captureSource = source.slice(source.indexOf('async function captureSecondaryHudOriginals'), source.indexOf('async function setup'));
  const inspector = source.slice(source.indexOf('async function inspectSecondaryHudReachability'), source.indexOf('async function inspectDirectSafetyHud'));
  const rect = { x: 10, y: 10, left: 10, top: 10, right: 210, bottom: 110, width: 200, height: 100 };
  class Element {
    hidden = false; isConnected = true; parentElement: Element | null = null; dataset: any = {}; className = ''; tagName = 'DIV';
    clientLeft = 0; clientTop = 0; clientWidth = 200; clientHeight = 100; scrollWidth = 200; scrollHeight = 100; scrollTop = 0;
    constructor(public id: string, public textContent: string) {}
    contains(n: Element) { for (let p: Element | null = n; p; p = p.parentElement) if (p === this) return true; return false; }
    getBoundingClientRect() { return rect; }
    closest(selector: string) { if (selector !== '#hud-mode') return null; for(let p: Element | null = this; p; p = p.parentElement) if(p.id === 'mode') return p; return null; }
    getAttribute(k: string) { return k === 'aria-label' ? '残弾数' : k === 'role' ? 'status' : k === 'aria-live' ? 'polite' : null; }
    querySelector(selector: string) { return values[selector] ?? null; }
  }
  const details = new Element('campaign-hud-details', '');
  const values: Record<string, any> = { '#remaining-time': { textContent: '19:56' }, '#mg-ammo': { textContent: '0' }, '#cannon-ammo': { textContent: '0' } };
  const nodes: Record<string, Element> = {};
  const descriptors = [
    ['campaign-threat', '#campaign-threat', '砲台の魔法 · 自機を照準中 · 陣地1 · 1.2秒'], ['reload-status', '#reload-status', '再装填中 あと1.8秒'],
    ['campaign-limit', '.campaign-limit', '期限まで 19:56'], ['ammo', '.ammo', '機銃 0 · 機関砲 0'],
    ['mode', '#hud-mode', 'イージー'], ['timer', '.time-block', '作戦経過 00:04.00'], ['score', '.score-readout', 'スコア 0'], ['wingmen', '.wingmen', '味方兵 168 · 予備 336'],
  ];
  for (const [key, selector, text] of descriptors) {
    const n = nodes[key] = new Element(key, text); values[selector] = n;
    if (['timer', 'score', 'wingmen'].includes(key) || change === 'fixed-in-details') { n.parentElement = details; n.dataset.campaignDetail = key; }
  }
  if (change === 'secondary-outside') nodes.timer.parentElement = null;
  if (change === 'stale-ammo') values['#mg-ammo'].textContent = '288';
  if (change === 'stale-time') values['#remaining-time'].textContent = '20:00';
  if (change === 'stale-reload') nodes['reload-status'].textContent = '再装填中 あと9.9秒';
  if (change === 'dormant-reload') { nodes['reload-status'].textContent = ''; nodes['reload-status'].hidden = true; }
  if (change === 'false-protection') nodes['campaign-threat'].textContent = '復活保護 · 発砲できません · 9.9秒';
  if (change === 'stale-threat-time') nodes['campaign-threat'].textContent = '砲台の魔法 · 自機を照準中 · 陣地1 · 9.9秒';
  if (change === 'stale-threat-site') nodes['campaign-threat'].textContent = '砲台の魔法 · 自機を照準中 · 陣地4 · 1.2秒';
  const raw = { screen: 'playing', phase: 'playing', player: { reloadTicksRemaining: change === 'dormant-reload' ? 0 : 108 },
    campaign: { mode: 'easy', activeTicks: 240, simTick: 240, status: 'running', actors: [{ hp: 600, team: 'enemy', class: 'turret', phase: 'telegraph', laneId: 0, fireAtTick: 312, lockedAim: null, targetRef: { id: 1, generation: change === 'stale-threat-generation' ? 0 : 1 } }], player: { id: 1, generation: 1, mg: 0, cannon: 0,
      reloadUntilTick: change === 'dormant-reload' ? null : 348, protectionTicks: 0 } } };
  if (change === 'mode-reparent') { nodes.mode.parentElement = nodes.timer; nodes.timer.textContent += nodes.mode.textContent; }
  if (change === 'wrong-mode') nodes.mode.textContent = 'ノーマル';
  if (change === 'hidden-mode') nodes.mode.hidden = true;
  if (change === 'missing-mode') delete values['#hud-mode'];
  if (change.startsWith('protection-') || change === 'actual-protection') {
    Object.assign(raw.campaign, { selfLosses: 1 });
    raw.campaign.player.generation = 2; raw.campaign.player.protectionTicks = 63;
    nodes['campaign-threat'].textContent = change === 'protection-stale' ? '復活保護 あと2.0秒 · 自機攻撃不可'
      : change === 'protection-no-attack' ? '復活保護 あと1.1秒' : '復活保護 あと1.1秒 · 自機攻撃不可';
    nodes['campaign-threat'].hidden = change === 'protection-hidden';
  }
  const document = { querySelector(s: string) { return s === '#campaign-hud-details' ? details : values[s]; },
    querySelectorAll(s: string) { return values[s] ? (change === 'duplicate-fixed' && s === '.ammo' || change === 'duplicate-mode' && s === '#hud-mode') ? [values[s], values[s]] : [values[s]] : []; },
    createTreeWalker(n: Element) {
      const child = new Element('hidden-child', n.textContent); child.parentElement = n;
      const modeInside = n === nodes.timer && nodes.mode.parentElement === n;
      const list: any[] = [{ textContent: modeInside ? n.textContent.slice(0, -nodes.mode.textContent.length) : n.textContent, parentElement: change === 'hidden-child' ? child : n }];
      if (modeInside) list.push({ textContent: nodes.mode.textContent, parentElement: nodes.mode });
      if (n.id === 'timer' && ['collapsed-indentation', 'preserved-whitespace', 'unmeasurable-nbsp', 'unmeasurable-mixed-text'].includes(change))
        list.unshift({ textContent: change === 'unmeasurable-nbsp' ? '\u00a0' : change === 'unmeasurable-mixed-text' ? 'A ' : '\n            ', parentElement: n });
      return { nextNode() { return list.shift() ?? null; } };
    },
    createRange() { return { startContainer: null as any, startOffset: 0, endOffset: 0, setStart(container: any, offset: number) { this.startContainer = container; this.startOffset = offset; }, setEnd(_container: any, offset: number) { this.endOffset = offset; }, cloneRange() { return { ...this }; }, collapse() {}, getBoundingClientRect() {
      if (/^[\t\n\f\r ]+$/.test(this.startContainer.textContent) || this.startContainer.textContent === '\u00a0' || this.startContainer.textContent === 'A ') return { x: 0, y: 0, left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 };
      return change === 'clipped-fixed' ? { ...rect, left: -5, x: -5 } : { ...rect, width: 2, right: 12, height: 10, bottom: 20 };
    } }; },
  };
  const inspect = runInNewContext(transpileModule(`${registry}\n${captureSource}\n${inspector}\n({ inspect: inspectSecondaryHudReachability, capture: captureSecondaryHudOriginals });`, {
    compilerOptions: { target: ScriptTarget.ES2022, module: ModuleKind.None },
  }).outputText, { window: { __fantasiaReadState: () => raw }, document, HTMLElement: Element, NodeFilter: { SHOW_TEXT: 4 }, innerWidth: 568, innerHeight: 320,
    getComputedStyle(n: Element) { return { whiteSpace: change === 'preserved-whitespace' ? 'pre' : 'normal', display: 'block', visibility: 'visible', opacity: n.id === 'hidden-child' ? '0' : '1', contentVisibility: 'visible',
      clipPath: 'none', clip: 'auto', contain: '', overflowX: 'visible', overflowY: n === details ? 'auto' : 'visible' }; } });
  const captured = await inspect.capture({ evaluateHandle(fn: any, input: any) { const saved = fn(input); return { evaluate(cb: any, value: any) { return cb(saved, value); } }; }, evaluate(fn: any, input: any) { return fn(input); } });
  if (change === 'mode-reparent') {
    nodes.timer.textContent = nodes.timer.textContent.slice(0, -nodes.mode.textContent.length); nodes.mode.parentElement = null;
  }
  return inspect.inspect(null, captured.originalNodes, captured.originalText);
}
test('HUD contract accepts original fixed critical nodes and genuinely secondary scrolling nodes', async () => {
  const result = await inspectReadoutContract(); assert.equal(result.ok, true, JSON.stringify(result.issues));
});
for (const variant of ['fixed-in-details', 'secondary-outside', 'clipped-fixed', 'duplicate-fixed', 'stale-ammo', 'stale-reload', 'stale-time', 'false-protection', 'stale-threat-time', 'stale-threat-site', 'stale-threat-generation', 'hidden-child'] as const)
  test(`HUD contract rejects ${variant} without relaxing full-text or identity checks`, async () => {
    assert.equal((await inspectReadoutContract(variant)).ok, false);
  });

test('HUD contract accepts an empty hidden reload only when the authoritative reload is inactive', async () => {
  const result = await inspectReadoutContract('dormant-reload'); assert.equal(result.ok, true, JSON.stringify(result.issues));
});

async function inspectReloadPixels(active: boolean, pixels: number, threatActive = false, threatPoint: object | null = null) {
  const source = readFileSync(new URL('../browser-ui-only/ui-only.spec.ts', import.meta.url), 'utf8');
  const check = source.slice(source.indexOf('async function checkCanvasPixels'), source.indexOf('function recordHudFailure'));
  const run = runInNewContext(transpileModule(`${check}\ncheckCanvasPixels;`, {
    compilerOptions: { target: ScriptTarget.ES2022, module: ModuleKind.None },
  }).outputText, { expect: browserExpect });
  return run({ evaluate() { return { alphaPixels: 1000, ring: 100, reloadRing: pixels, reloadActive: active,
    centerDot: 4, radarPixels: 300, warningPixels: 10, threatActive, crosshair: [1, 1, 1, 1] }; } }, 'normal', { threatPoint });
}
test('HUD pixels do not require a dormant reload arc after genuine respawn', async () => {
  await inspectReloadPixels(false, 0);
});
test('HUD pixels still reject a missing active reload arc', async () => {
  await assert.rejects(inspectReloadPixels(true, 0));
});

test('HUD pixels reject a missing projected point for an active authoritative threat', async () => {
  await assert.rejects(inspectReloadPixels(false, 0, true, null));
});

test('HUD contract accepts collapsed HTML indentation without dropping meaningful glyphs', async () => {
  const result = await inspectReadoutContract('collapsed-indentation'); assert.equal(result.ok, true, JSON.stringify(result.issues));
});
test('HUD contract still rejects unmeasurable preserved whitespace', async () => {
  assert.equal((await inspectReadoutContract('preserved-whitespace')).ok, false);
});

for (const variant of ['unmeasurable-nbsp', 'unmeasurable-mixed-text'] as const)
  test(`HUD contract does not discard ${variant} as HTML indentation`, async () => {
    assert.equal((await inspectReadoutContract(variant)).ok, false);
  });

test('HUD contract retains an original mode moved out of the timer during compact reflow', async () => {
  const result = await inspectReadoutContract('mode-reparent'); assert.equal(result.ok, true, JSON.stringify(result.issues));
});
for (const variant of ['missing-mode', 'wrong-mode', 'duplicate-mode', 'hidden-mode'] as const)
  test(`HUD contract rejects ${variant} independently of timer text`, async () => {
    assert.equal((await inspectReadoutContract(variant)).ok, false);
  });


test('canonical protection inspector accepts correct state and rejects stale, incomplete or hidden projection', async () => {
  assert.equal((await inspectReadoutContract('actual-protection')).ok, true);
  for (const variant of ['protection-stale', 'protection-no-attack', 'protection-hidden'] as const)
    assert.equal((await inspectReadoutContract(variant)).ok, false, variant);
});


test('announcement visibility gate accepts only a fully validated canonical projection', () => {
  const source = readFileSync('browser-ui-only/ui-only.spec.ts', 'utf8');
  const gate = source.slice(source.indexOf("  recordHudAssertion(failures, provenance, name, 'announcement-visible',"), source.indexOf("  recordHudAssertion(failures, provenance, name, 'announcement-text',"));
  const check = (visible: boolean, ok: boolean, route: string) => runInNewContext(gate, {
    failures: [], provenance: 'unit', name: 'unit', expect: browserExpect,
    domEvidence: { announcement: { visible } }, announcementReachability: { ok, route },
    recordHudAssertion: (_a: unknown, _b: unknown, _c: unknown, _d: unknown, assertion: () => void) => assertion(),
  });
  const projection = 'single fixed protection projection; duplicate announcement hidden';
  assert.doesNotThrow(() => check(false, true, projection));
  assert.doesNotThrow(() => check(true, true, 'original announcement'));
  assert.throws(() => check(false, false, projection));
  assert.throws(() => check(false, true, 'original announcement'));
});

// DOM-contract mock only: these tests do not prove browser geometry or glyph visibility.
const wholeFlowHarnessSource = `/** Deterministic DOM-contract harness only. No glyph, CSS layout, or browser claim. */
const runFlowProbeHarness=function(install,{throwOnAppend=false,hideAfterInstall=false}={}) {
 const globals=['document','getComputedStyle','Node'].map(k=>[k,Object.getOwnPropertyDescriptor(globalThis,k)]);
 class NodeMock {
  constructor(id=''){Object.assign(this,{id,className:id,children:[],dataset:{},attrs:{},hidden:false,textContent:'原文 '+id,clientWidth:100,scrollWidth:100});this.style={setProperty:(k,v)=>{this.attrs.style=(this.attrs.style||'')+\`\${k}:\${v};\`}};}
  get parentNode(){return this.parentElement}get nextSibling(){if(!this.parentElement)return null;return this.parentElement.children[this.parentElement.children.indexOf(this)+1]??null}
  get isConnected(){for(let n=this;n;n=n.parentElement)if(n.id==='app')return true;return false}get childNodes(){return this.children}
  querySelectorAll(s){return s==='*'?this.children.flatMap(n=>[n,...n.querySelectorAll('*')]):[]}
  contains(n){for(;n;n=n.parentElement)if(n===this)return true;return false}getBoundingClientRect(){return {x:8,y:10,width:100,height:30}}getClientRects(){return [this.getBoundingClientRect()]}
  closest(){return null}
  getAttribute(k){return this.attrs[k]??null}setAttribute(k,v){this.attrs[k]=v}removeAttribute(k){delete this.attrs[k]}
  before(a){a.parentElement=this.parentElement;this.parentElement.children.splice(this.parentElement.children.indexOf(this),0,a)}
  append(...ns){for(const n of ns){n.remove();n.parentElement=this;this.children.push(n)}}
  remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(n=>n!==this);this.parentElement=null}
  replaceWith(n){const p=this.parentElement;n.remove();const i=p.children.indexOf(this);p.children.splice(i,1,n);n.parentElement=p;this.parentElement=null}
  matches(s){return this.id==='pause'&&s.includes('button')}
 }
 const app=new NodeMock('app'),hud=new NodeMock('hud'),flight=new NodeMock('flight-data');app.append(hud);hud.append(flight);
 const names=['health-label','health-track','campaign-limit','ammo','campaign-mode-status','instrument'],nodes=names.map(n=>new NodeMock(n));flight.append(...nodes);
 const control=new NodeMock('pause');hud.append(control);const roots=[...nodes,control],originalOrder=[...flight.children];
 app.querySelector=()=>hud;app.querySelectorAll=s=>s.startsWith('.flight-data > *')?roots:nodes.filter(n=>n.id===s.slice(1));
 const append=hud.append.bind(hud);hud.append=(n)=>{if(throwOnAppend&&n.dataset.wholeFlowProbe==='numeric')throw Error('injected append failure');append(n)};
 globalThis.document={querySelector:()=>app,createComment:()=>new NodeMock('anchor'),createElement:()=>new NodeMock('new')};
 globalThis.getComputedStyle=n=>({display:'block',visibility:n.hidden?'hidden':'visible',opacity:'1',getPropertyValue:()=> '16px'});globalThis.Node={TEXT_NODE:3};
 let error,reading,restoreResult;
 try {
  let probe;try{probe=install({bounds:{x:8,y:8,width:304,height:552},fixed:Array.from({length:7},()=>({id:'campaign-site',x:8,y:8,width:50,height:40})),portrait:true});if(hideAfterInstall)nodes[0].hidden=true;reading=probe.read();}catch(e){error=String(e)}finally{if(probe){nodes[0].hidden=false;restoreResult=probe.restore()}}
  return {error,reading,restoreResult,parentsRestored:nodes.every(n=>n.parentElement===flight),orderRestored:flight.children.length===originalOrder.length&&flight.children.every((n,i)=>n===originalOrder[i]),inlineRestored:roots.every(n=>n.getAttribute('style')===null),anchorsRemaining:flight.children.filter(n=>n.id==='anchor').length};
 } finally {for(const [key,descriptor] of globals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key]}}
};
`;
function inspectWholeFlowProbe(options: { throwOnAppend?: boolean; hideAfterInstall?: boolean } = {}) {
  const spec = readFileSync(new URL('../browser-ui-only/ui-only.spec.ts', import.meta.url), 'utf8');
  const fn = spec.slice(spec.indexOf('function installHudWholeFlowProbe('), spec.indexOf('async function captureHudWholeFlowProbe('));
  assert.ok(fn.includes('return {initial:read(),read,restore}'));
  const source = transpileModule(`${fn}\n${wholeFlowHarnessSource}\nrunFlowProbeHarness(installHudWholeFlowProbe, ${JSON.stringify(options)});`, {
    compilerOptions: { target: ScriptTarget.ES2022, module: ModuleKind.None },
  }).outputText;
  return JSON.parse(JSON.stringify(runInNewContext(source)));
}
test('whole-flow diagnostic restores original parent, sibling order and styles after installation exception', () => {
  const result = inspectWholeFlowProbe({ throwOnAppend: true });
  assert.match(result.error, /injected append failure/);
  assert.equal(result.parentsRestored, true); assert.equal(result.orderRestored, true); assert.equal(result.inlineRestored, true);
  assert.equal(result.anchorsRemaining, 0);
});
test('whole-flow diagnostic retains original semantic leaves after grouping and restores them', () => {
  const result = inspectWholeFlowProbe();
  assert.equal(result.error, undefined); assert.equal(result.reading.originalLeafCount, 7); assert.equal(result.reading.retainedLeafCount, 7);
  assert.deepEqual(result.reading.invariants, []);
  assert.deepEqual(result.reading.leaves.map((item: {id:string}) => item.id), ['health-label', 'health-track', 'campaign-limit', 'ammo', 'campaign-mode-status', 'instrument', 'pause']);
  assert.equal(result.restoreResult, true); assert.equal(result.orderRestored, true); assert.equal(result.inlineRestored, true);
});
test('whole-flow diagnostic rejects original leaf visibility changes after grouping', () => {
  const result = inspectWholeFlowProbe({ hideAfterInstall: true });
  assert.equal(result.error, undefined);
  assert.ok(result.reading.invariants.some((item: {id:string;issue:string}) => item.id === 'health-label' && item.issue === 'visibility-changed'));
  assert.equal(result.restoreResult, true);
});
