import { defineConfig } from 'vite';
import { uiOnlyTestPlugin } from './vite.ui-only-plugin.mjs';

export default defineConfig({
  base: './',
  plugins: [uiOnlyTestPlugin()],
  // The virtual UI-only scene imports the real overlay implementation. Vite's
  // HTML scan cannot follow that virtual entry; discovering its Three addons
  // after the page is ready would restart optimization and reload the test.
  optimizeDeps: {
    entries: ['index.html'],
    include: [
      'three',
      'three/addons/utils/BufferGeometryUtils.js',
      'three/addons/lines/LineSegments2.js',
      'three/addons/lines/LineSegmentsGeometry.js',
      'three/addons/lines/LineMaterial.js',
    ],
  },
  server: { host: '127.0.0.1', port: 4177, strictPort: true },
  build: { sourcemap: false },
});
